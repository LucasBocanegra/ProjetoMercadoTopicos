package br.com.starcode.matheusTest;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import br.com.starcode.logic.Cliente;
import br.com.starcode.logic.Mercado;
import br.com.starcode.logic.Produto;
import br.com.starcode.logic.RegistroVenda;

public class Teste_Altera��o_RegistroDeVenda {
	private RegistroVenda RV;		
	private Produto produto, Produto1, Produto2, Produto3, Produto4, Produto5,Produto6;
	
	@Before
	public void Criacao () {
		
		Mercado m = new Mercado();		
				
		produto = new Produto(0,"Arroz",5.00,6.99,"Un",100,1);
		Produto1 = new Produto(1,"Feijao",3.00,4.99,"Un",100,1);
		Produto2 = new Produto(2,"Milho",1.00,2.99,"Un",100,1);
		Produto3 = new Produto(3,"Cafe",1.50,2.99,"Un",100,1);
		Produto4 = new Produto(4,"Bolacha",0.50,0.99,"Un",100,1);
		Produto5 = new Produto(5,"Macarrao",1.50,2.99,"Un",100,1);
		Produto6 = new Produto(6,"Leite",0.70,1.20,"Un",0,0);

		m.cadastrarProduto(produto);
		m.cadastrarProduto(Produto1);
		m.cadastrarProduto(Produto2);
		m.cadastrarProduto(Produto3);
		m.cadastrarProduto(Produto4);
		m.cadastrarProduto(Produto5);
		m.cadastrarProduto(Produto6);
		
		Cliente c = new Cliente("matheus santos", "37413815869", "av. xyz", "(16)997765478", "matheus@ufscar.com.br", 1);
		
		m.cadastrarCliente(c);
				
		RV = new RegistroVenda("0;37413815869;09/06/2015;0;7.00;1;5.00;");

	}

	
	
	@Test(expected = RuntimeException.class)
	public void CTRVA1() {
		RV.setNumero(-1);	
		
	}
	
	@Test(expected = RuntimeException.class)
	public void CTRVA2() {
		RV.setData("32/05/2015");		
		}
	
	@Test(expected = RuntimeException.class)
	public void CTRVA3() {
		RV.setData("05/13/2015");		
		}
	
	@Test(expected = RuntimeException.class)
	public void CTRVA4() {
		RV.setData("09/06/2010;0");		
	}
	
	@Test
	public void CTRVA5() {
		RV.setData("09/06/2016");	
		}
	
	@Test(expected = RuntimeException.class)
	public void CTRVA6() {
		RV.setData("30/02/2015");		
	}
	
	@Ignore //caso de teste inutil 
	public void CTRVA7() {
		RV = new RegistroVenda("1;37413815869;09/06/2015;0;7.00;1;5.00;");		
	}
	
	@Test(expected = Exception.class)
	public void CTRVA8() {
		RV.setQuantidadeItens(0);		
	}
	
	@Test(expected = Exception.class)
	public void CTRVA9() {
		RV.setQuantidadeItens(5);
		ArrayList<Double> array1 = new ArrayList<Double>();	
		array1.add(1.00);
		array1.add(2.00);
		array1.add(7.00);
		array1.add(5.00);
		RV.setQuantidades(array1);
		ArrayList<Produto> Produtos = new ArrayList<Produto>();
		Produtos.add(produto);
		Produtos.add(Produto1);
		Produtos.add(Produto2);
		Produtos.add(Produto3);
		Produtos.add(Produto4);
		RV.setProdutos(Produtos);
	}
	
	@Test(expected = Exception.class)
	public void CTRVA10() {
		
		ArrayList<Produto> Produtos = new ArrayList<Produto>();
		Produtos.add(produto);
		Produtos.add(Produto6);
		RV.setProdutos(Produtos);		
	}
	
	@Test(expected = RuntimeException.class)
	public void CTRVA11() {
		RV.setData("00/06/2015");
	}
	
	@Test()
	public void CTRVA12() {
		RV.setData("01/06/2015");	
		//testar um no dia na an�lise do valor limite
	}
	
	@Test(expected = RuntimeException.class)
	public void CTRVA13() {
		RV.setData("31/06/2015");		
	//testar 31 na an�lise do valor limite
	}
	
	@Test(expected = RuntimeException.class)
	public void CTRVA14() {
		RV.setData("10/00/2015");		
	}
	
	@Test()
	public void CTRVA15() {
		RV.setData("10/01/2015");		
	}
	
	/*ESTA DANDO ERRO FAVOR COMENTAR A FUNCIONALIDADE*/	
	@Test()
	public void CTRVA16() {
		RV.setData("10/12/2015");
		//testar 12 no mes na an�lise do valor limite
	}
	
		
	@Test()
	public void CTRVA17() {
		ArrayList<Double> quantidades = new ArrayList<Double>();
		quantidades.add(7.00);
		RV.setQuantidadeItens(1);
		RV.setQuantidades(quantidades);
		ArrayList<Produto> produtos = new ArrayList<Produto>();
		produtos.add(produto);
		RV.setProdutos(produtos);
		//testar passando apenas 1 produto e um valor para RegistroVenda
	}
	
	/*ESTA DANDO ERRO FAVOR COMENTAR A FUNCIONALIDADE*/	
	@Test()
	public void CTRVA18() {
		ArrayList<Double> quantidades = new ArrayList<Double>();
		quantidades.add(0.01);
		RV.setQuantidadeItens(1);
		RV.setQuantidades(quantidades);
		ArrayList<Produto> produtos = new ArrayList<Produto>();
		produtos.add(produto);
		RV.setProdutos(produtos);		
		//testar passando o valor 0.01 como quantidade comprada para RegistroVenda
	}
	
	@Test(expected = RuntimeException.class)
	public void CTRVA19() {
		ArrayList<Double> quantidades = new ArrayList<Double>();
		quantidades.add(0.01);
		RV.setQuantidades(quantidades);
		ArrayList<Produto> produtos = new ArrayList<Produto>();
		RV.setProdutos(produtos);		
	}
	
	@Test(expected = RuntimeException.class)
	public void CTRVA20() {
		ArrayList<Double> quantidades = new ArrayList<Double>();
		RV.setQuantidades(quantidades);
		ArrayList<Produto> produtos = new ArrayList<Produto>();
		produtos.add(produto);
		RV.setProdutos(produtos);			
	}
	


}
