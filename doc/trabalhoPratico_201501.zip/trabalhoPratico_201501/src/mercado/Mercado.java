/**
 * 
 */
package mercado;

/**
 * @author ferrari
 *
 */
public class Mercado {

}
